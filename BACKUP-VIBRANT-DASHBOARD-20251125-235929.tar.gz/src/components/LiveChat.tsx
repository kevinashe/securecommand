import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Send, Users, User, X, MessageCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  company_id: string;
  sender_id: string;
  recipient_id: string | null;
  message: string;
  is_read: boolean;
  created_at: string;
  sender?: {
    full_name: string;
    role: string;
  };
}

interface ChatUser {
  id: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

export const LiveChat: React.FC = () => {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [users, setUsers] = useState<ChatUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadUsers();
    loadMessages();

    const subscription = supabase
      .channel('chat_messages_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `company_id=eq.${profile?.company_id}`
        },
        () => {
          loadMessages();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [profile?.company_id]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (selectedUser) {
      markMessagesAsRead();
    }
  }, [selectedUser, messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, role, is_active')
        .eq('company_id', profile?.company_id)
        .neq('id', profile?.id)
        .order('full_name');

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async () => {
    try {
      console.log('Loading messages for company:', profile?.company_id);
      console.log('Current user ID:', profile?.id);

      const { data: messagesData, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('company_id', profile?.company_id)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Supabase error loading messages:', error);
        alert(`Error loading messages: ${error.message}`);
        throw error;
      }

      console.log('Loaded messages count:', messagesData?.length);
      console.log('Loaded messages:', messagesData);

      if (!messagesData || messagesData.length === 0) {
        setMessages([]);
        return;
      }

      const senderIds = [...new Set(messagesData.map(m => m.sender_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, role')
        .in('id', senderIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

      const formattedData = messagesData.map((item: any) => ({
        ...item,
        sender: profileMap.get(item.sender_id)
      }));

      console.log('Setting messages state with:', formattedData.length, 'messages');
      setMessages(formattedData);
    } catch (error) {
      console.error('Catch block - Error loading messages:', error);
    }
  };

  const markMessagesAsRead = async () => {
    try {
      await supabase
        .from('chat_messages')
        .update({ is_read: true })
        .eq('recipient_id', profile?.id)
        .eq('sender_id', selectedUser)
        .eq('is_read', false);
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newMessage.trim() || !profile?.company_id) return;

    setSending(true);

    try {
      const { error } = await supabase
        .from('chat_messages')
        .insert([
          {
            company_id: profile.company_id,
            sender_id: profile.id,
            recipient_id: selectedUser,
            message: newMessage.trim(),
            is_read: false
          }
        ]);

      if (error) throw error;

      setNewMessage('');
      loadMessages();
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const getFilteredMessages = () => {
    if (!selectedUser) {
      return messages.filter(m => m.recipient_id === null);
    }

    const filtered = messages.filter(
      m =>
        (m.sender_id === profile?.id && m.recipient_id === selectedUser) ||
        (m.sender_id === selectedUser && m.recipient_id === profile?.id)
    );

    console.log('Filtering messages:', {
      totalMessages: messages.length,
      selectedUser,
      currentUserId: profile?.id,
      filteredCount: filtered.length,
      filtered
    });

    return filtered;
  };

  const getUnreadCount = (userId: string) => {
    return messages.filter(
      m =>
        m.sender_id === userId &&
        m.recipient_id === profile?.id &&
        !m.is_read
    ).length;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const filteredMessages = getFilteredMessages();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Live Chat</h1>
        <p className="text-gray-600 mt-2">Communicate with your team in real-time</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4">
            <div className="flex items-center justify-between text-white">
              <h2 className="text-lg font-semibold">Contacts</h2>
              <Users className="h-5 w-5" />
            </div>
          </div>

          <div className="p-4">
            <button
              onClick={() => setSelectedUser(null)}
              className={`w-full flex items-center space-x-3 p-3 rounded-xl mb-2 transition-all duration-200 ${
                selectedUser === null
                  ? 'bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-500 shadow-sm'
                  : 'hover:bg-gray-50 border-2 border-transparent hover:shadow-sm'
              }`}
            >
              <div className={`${selectedUser === null ? 'bg-blue-600' : 'bg-blue-100'} p-2.5 rounded-xl`}>
                <MessageCircle className={`h-5 w-5 ${selectedUser === null ? 'text-white' : 'text-blue-600'}`} />
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-gray-900">Group Chat</p>
                <p className="text-xs text-gray-500">Everyone in team</p>
              </div>
            </button>

            <div className="space-y-2">
              {users.map((user) => {
                const unreadCount = getUnreadCount(user.id);
                return (
                  <button
                    key={user.id}
                    onClick={() => setSelectedUser(user.id)}
                    className={`w-full flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${
                      selectedUser === user.id
                        ? 'bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-500 shadow-sm'
                        : 'hover:bg-gray-50 border-2 border-transparent hover:shadow-sm'
                    }`}
                  >
                    <div className={`${selectedUser === user.id ? 'bg-blue-600' : 'bg-gray-200'} p-2.5 rounded-xl relative`}>
                      <User className={`h-5 w-5 ${selectedUser === user.id ? 'text-white' : 'text-gray-600'}`} />
                      {user.is_active && (
                        <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-green-500 border-2 border-white rounded-full"></span>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-semibold text-gray-900 text-sm">{user.full_name}</p>
                      <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                    </div>
                    {unreadCount > 0 && (
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center shadow-md">
                        {unreadCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="lg:col-span-3 bg-white rounded-xl shadow-lg border border-gray-100 flex flex-col h-[700px] overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4 flex items-center justify-between">
            <div className="text-white">
              <h2 className="text-lg font-semibold">
                {selectedUser
                  ? users.find(u => u.id === selectedUser)?.full_name || 'Unknown User'
                  : 'Group Chat'}
              </h2>
              <p className="text-sm text-blue-100 capitalize">
                {selectedUser
                  ? users.find(u => u.id === selectedUser)?.role
                  : 'Team communication'}
              </p>
            </div>
            {selectedUser && (
              <button
                onClick={() => setSelectedUser(null)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors text-white"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-gray-50 to-white">
            {filteredMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="bg-gradient-to-r from-blue-100 to-blue-200 p-6 rounded-full mb-4">
                  <MessageCircle className="h-16 w-16 text-blue-600" />
                </div>
                <p className="text-gray-700 text-lg font-semibold">No messages yet</p>
                <p className="text-gray-500 text-sm mt-1">Start a conversation below</p>
              </div>
            ) : (
              filteredMessages.map((message) => {
                const isOwn = message.sender_id === profile?.id;
                return (
                  <div
                    key={message.id}
                    className={`flex ${isOwn ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}
                  >
                    <div
                      className={`max-w-[70%] ${
                        isOwn
                          ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md'
                          : 'bg-white text-gray-900 shadow-sm border border-gray-200'
                      } rounded-2xl p-4 transition-all duration-200 hover:shadow-lg`}
                    >
                      {!isOwn && (
                        <p className="text-xs font-semibold mb-2 text-blue-600">
                          {message.sender?.full_name}
                        </p>
                      )}
                      <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">{message.message}</p>
                      <p
                        className={`text-xs mt-2 ${
                          isOwn ? 'text-blue-100' : 'text-gray-400'
                        }`}
                      >
                        {new Date(message.created_at).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={sendMessage} className="p-4 bg-white border-t border-gray-200">
            <div className="flex space-x-3">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={`Message ${
                  selectedUser
                    ? users.find(u => u.id === selectedUser)?.full_name || 'user'
                    : 'everyone'
                }...`}
                className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                disabled={sending}
              />
              <button
                type="submit"
                disabled={!newMessage.trim() || sending}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 shadow-md hover:shadow-lg"
              >
                <Send className="h-5 w-5" />
                <span className="font-medium">Send</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
